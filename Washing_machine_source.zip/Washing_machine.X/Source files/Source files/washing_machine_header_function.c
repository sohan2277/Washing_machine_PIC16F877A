#ifndef WASHING_MACHINE_HEADER_FUNCTION_C
#define	WASHING_MACHINE_HEADER_FUNCTION_C

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* WASHING_MACHINE_HEADER_FUNCTION_C */

